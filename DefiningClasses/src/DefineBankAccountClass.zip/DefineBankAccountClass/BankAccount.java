package DefineBankAccountClass;

public class BankAccount {
    private int id;
    private double balance;

    //constructor


    public BankAccount(int id) {
        this.id = id;
        this.balance = 0.0;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getBalance() {
        return this.balance;
    }

    void deposit(double ammount) {

        this.balance += ammount;
    }

    void withdraw(double ammount) {
        if (this.balance - ammount < 0) {
            System.out.println("Insufficient balance");
        } else {
            this.balance -= ammount;
        }
    }


    @Override
    public String toString() {
        return String.format("Account ID%d, balance %.2f", this.id, this.balance);
    }
}
