package com.company;

public class Main {

    public static void main(String[] args) {

        Rectangle r = new Rectangle(2.5,5);
        Rectangle s = new Square(3, 4.6);

        r.area();
        s.area();

    }
}
