package com.Shapes;

public class Main {
    public static void main(String[] args) {

        Shape rec = new Rectangle(2,5);
        Shape circle = new Circle(2.44);

        System.out.println(circle.calculateArea());
        System.out.println(circle.calculatePerimeter());
        System.out.println();
        System.out.println(rec.calculateArea());
        System.out.println(rec.calculatePerimeter());
    }
}
