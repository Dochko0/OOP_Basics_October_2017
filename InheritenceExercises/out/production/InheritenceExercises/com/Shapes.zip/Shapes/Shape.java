package com.Shapes;

public abstract class Shape {

    private double perimeter;
    private double area;


    Shape() {}

    protected abstract double calculatePerimeter();

    protected abstract double calculateArea();


    public double getPerimeter() {
        return perimeter;
    }
}
