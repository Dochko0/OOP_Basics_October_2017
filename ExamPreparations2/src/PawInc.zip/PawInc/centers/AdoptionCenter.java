package PawInc.centers;


import PawInc.animals.Animal;

import java.util.List;

public class AdoptionCenter extends Center {

    public AdoptionCenter(String name, List<Animal> storedAnimals) {
        super(name);
    }

    public void sendForCleance(String cleasingCentername){

    }

    public void adoptAnimal(){

    }
}

//public class AdoptionCenter extends Center {
//
//    public AdoptionCenter(String name, List<Animal> storedAnimals) {
//        super(name);
//    }
//
//    public void sendForCleanse (String cleansingCentername){
//
//    }
//
//    public void adoptAnimal(){
//
//    }
//}
