package PawInc.centers;

import PawInc.animals.Animal;

import java.util.ArrayList;
import java.util.List;

//public class CleasingCenter extends Center {
//
//
//    public CleasingCenter(String name,List<Animal> storedAnimals) {
//        super(name);
//    }
//
//    public List<Animal> cleance(List<Animal> animalsForCleasing){
//        return new ArrayList<>();
//    }
//}

public class CleansingCenter extends Center {

    public CleansingCenter(String name, List<Animal> storedAnimals) {

        super(name);
    }

    public List<Animal> cleanse(List<Animal> animalsForCleasing) {

        return new ArrayList<>();
    }
}
