package PawInc.animals;

public class Dog extends Animal{

    private int amountOfCommands;

    public Dog(String name, int age,int amountOfCommands) {
        super(name, age);
        this.amountOfCommands=amountOfCommands;
    }

    public int getamountOfCommands() {
        return this.amountOfCommands;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}

//public class Dog extends Animal {
//    private int amountOfCommands;
//
//    public Dog(String name, int age, int amountOfCommands) {
//        super(name, age);
//        this.amountOfCommands = amountOfCommands;
//    }
//
//    public int getAmountOfCommands() {
//        return this.amountOfCommands;
//    }
//
//    @Override
//    public String toString() {
//        return super.toString();
//    }
//}
