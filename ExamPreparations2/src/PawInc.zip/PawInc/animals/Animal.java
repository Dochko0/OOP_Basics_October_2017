package PawInc.animals;

public abstract class Animal {

    private final String DEFAULT_CLEASING_STATUS = "UNCLEANSED";
    private String name;
    private int age;
    private String ceasingStatus;


    protected Animal(String name, int age) {
        this.setName(name);
        this.setAge(age);
        this.setCeasingStatus(DEFAULT_CLEASING_STATUS);
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    private void setAge(int age) {
        this.age = age;
    }

    private void setCeasingStatus(String ceasingStatus) {
        this.ceasingStatus = ceasingStatus;
    }

    public String getCeasingStatus() {
        return ceasingStatus;
    }
}
