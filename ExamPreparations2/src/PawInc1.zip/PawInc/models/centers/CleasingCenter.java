package PawInc.models.centers;

public class CleasingCenter extends Center {

    public CleasingCenter(String name) {
        super(name);
    }
}
