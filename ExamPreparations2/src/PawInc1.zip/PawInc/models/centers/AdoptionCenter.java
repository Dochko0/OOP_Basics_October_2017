package PawInc.models.centers;


public class AdoptionCenter extends Center {

    public AdoptionCenter(String name) {
        super(name);
    }
}
