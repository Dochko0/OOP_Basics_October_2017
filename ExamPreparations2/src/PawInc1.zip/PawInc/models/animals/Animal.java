package PawInc.models.animals;

public abstract class Animal {

    private String name;
    private int age;
    private boolean isCleansed;
    private String adoptionCenter;



    protected Animal(String name, int age) {
        this.setName(name);
        this.setAge(age);
        this.setUncleansed();
    }



    protected Animal(String name, int age, String adoptionCenter) {
        this(name, age);
        this.adoptionCenter = adoptionCenter;
    }

    public String getAdoptionCenter() {
        return this.adoptionCenter;
    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }

    public boolean isCleansed() {
        return this.isCleansed;
    }

    public void setName(String name) {
        this.name = name;
    }

    void setAge(int age) {
        this.age = age;
    }

    private void setUncleansed() {
        this.isCleansed = false;
    }

    private void setCleansed() {
        this.isCleansed = true;
    }

    @Override
    public String toString() {
        return this.getName();
    }
}
