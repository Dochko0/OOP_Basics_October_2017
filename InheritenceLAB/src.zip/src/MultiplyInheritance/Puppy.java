package MultiplyInheritance;

public class Puppy extends Dog{

    void weep(){
        System.out.println("weeping...");
    }
}
