package MultiplyInheritance;

public class Animal {

    final void eat(){
        System.out.println("eating...");
    }
}
