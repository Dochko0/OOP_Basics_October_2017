package HierarichalInheritance;

public class Cat extends Animal{
    void meow(){
        System.out.println("meowing...");
    }
}
