package avatar.benders;

public class AirBender extends Bender{

    private double aerialIntegirty;

    AirBender(String name, int power,double aerialIntegirty) {
        super(name, power);
        this.aerialIntegirty=aerialIntegirty;
    }
}
