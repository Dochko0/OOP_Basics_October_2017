package com.company;

public class Brand  extends MainBrand{

    public Brand(String name) {
        super(name);
    }


}
