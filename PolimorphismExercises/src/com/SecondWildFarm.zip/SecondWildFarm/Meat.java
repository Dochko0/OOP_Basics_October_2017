package com.SecondWildFarm;

public class Meat extends Food {
    public Meat(int quantity) {
        super(quantity);
    }
}
